Issen Impact Sound Rumble 1.0.1
Requires REFramework (install separately).
Complete package includes the sound, SDL runtime, launcher and scripts.
Vortex: install ZIP, set Mod Type to Loose Lua/Plugin (REFramework), enable, deploy, restart game.
Manual install: copy reframework folder beside OnimushaWotS.exe.
Settings: Script Generated UI > Issen Impact - DS4.
Source and build instructions: https://github.com/dodoisfree/IssenImpactSoundRumble
